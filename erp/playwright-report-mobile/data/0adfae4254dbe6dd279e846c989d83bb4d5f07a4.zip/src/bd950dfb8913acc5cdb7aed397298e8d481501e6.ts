/**
 * Testes E2E — Transações Manuais no App Mobile (Expo Web)
 * Porta: http://localhost:8081
 *
 * Cobertura:
 *  T1 — Criar transação de SAÍDA manual
 *  T2 — Criar transação de ENTRADA manual
 *  T3 — Editar uma transação existente
 *  T4 — Excluir uma transação
 *  T5 — Validar campos obrigatórios (sem preencher nada)
 */

import { test, expect, Page } from '@playwright/test';

const BASE_URL = 'http://localhost:8081';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/** Navega até a aba de Finanças e espera a tela carregar */
async function abrirFinancas(page: Page) {
  await page.goto(BASE_URL, { waitUntil: 'networkidle' });

  // Aguarda a barra de navegação inferior aparecer
  await page.waitForSelector('text=Financeiro', { timeout: 15000 });
  await page.getByText('Financeiro').first().click();

  // Aguarda a aba de Transações carregar
  await page.waitForSelector('text=Transações', { timeout: 10000 });
}

/** Abre o modal "+ Nova Transação" */
async function abrirNovaTransacao(page: Page) {
  const botaoNovo = page.locator('text=+ Nova Transação').or(
    page.locator('[aria-label="Nova Transação"]')
  ).or(
    page.locator('text=Nova')
  ).first();

  await botaoNovo.click();
  await page.waitForSelector('text=+ Nova Transação', { timeout: 8000 });
}

/** Seleciona o tipo da transação (Saída ou Entrada) */
async function selecionarTipo(page: Page, tipo: 'Saída' | 'Entrada') {
  await page.getByText(tipo).first().click();
  await page.waitForTimeout(400);
}

/** Preenche o valor da transação */
async function preencherValor(page: Page, valor: string) {
  const inputValor = page.locator('input[placeholder="0,00"]').or(
    page.locator('[placeholder="0,00"]')
  ).first();
  await inputValor.clear();
  await inputValor.fill(valor);
}

/** Preenche a descrição */
async function preencherDescricao(page: Page, descricao: string) {
  const inputDesc = page.locator('input[placeholder*="Abastecimento"]').or(
    page.locator('[placeholder*="Abastecimento"]')
  ).first();
  await inputDesc.clear();
  await inputDesc.fill(descricao);
}

/** Seleciona a forma de pagamento */
async function selecionarFormaPagamento(page: Page, forma: string) {
  await page.getByText(forma).first().click();
  await page.waitForTimeout(300);
}

/** Clica em Finalizar e aguarda o modal fechar */
async function confirmarSalvar(page: Page) {
  await page.getByText('Finalizar').click();
  await page.waitForSelector('text=Finalizar', { state: 'hidden', timeout: 10000 });
}

// ─────────────────────────────────────────────────────────────────────────────
// Testes
// ─────────────────────────────────────────────────────────────────────────────

test.describe('📱 Transações Manuais — App Mobile (Expo Web)', () => {
  test.beforeEach(async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
  });

  // ── T1 ────────────────────────────────────────────────────────────────────
  test('T1 — Criar transação de SAÍDA manual', async ({ page }) => {
    await abrirFinancas(page);
    await abrirNovaTransacao(page);

    await expect(page.getByText('+ Nova Transação').first()).toBeVisible();

    await selecionarTipo(page, 'Saída');
    await preencherValor(page, '250');
    await preencherDescricao(page, 'Teste Playwright - Conta de Luz');
    await selecionarFormaPagamento(page, 'PIX');

    await page.screenshot({ path: 'tests/screenshots/t1-antes-salvar.png', fullPage: true });
    await confirmarSalvar(page);

    await expect(page.getByText('Teste Playwright - Conta de Luz').first()).toBeVisible({ timeout: 8000 });
    await page.screenshot({ path: 'tests/screenshots/t1-criada.png', fullPage: true });
    console.log('✅ T1 — Saída criada com sucesso');
  });

  // ── T2 ────────────────────────────────────────────────────────────────────
  test('T2 — Criar transação de ENTRADA manual', async ({ page }) => {
    await abrirFinancas(page);
    await abrirNovaTransacao(page);

    await expect(page.getByText('+ Nova Transação').first()).toBeVisible();

    await selecionarTipo(page, 'Entrada');
    await preencherValor(page, '1500');
    await preencherDescricao(page, 'Teste Playwright - Recebimento Cliente');
    await selecionarFormaPagamento(page, 'Dinheiro');

    await page.screenshot({ path: 'tests/screenshots/t2-antes-salvar.png', fullPage: true });
    await confirmarSalvar(page);

    await expect(page.getByText('Teste Playwright - Recebimento Cliente').first()).toBeVisible({ timeout: 8000 });
    await page.screenshot({ path: 'tests/screenshots/t2-criada.png', fullPage: true });
    console.log('✅ T2 — Entrada criada com sucesso');
  });

  // ── T3 ────────────────────────────────────────────────────────────────────
  test('T3 — Editar transação existente', async ({ page }) => {
    await abrirFinancas(page);
    await page.waitForSelector('text=Teste Playwright', { timeout: 10000 });

    const menuBotao = page.locator('[aria-label="Opções"], [aria-label="Ações"]').or(
      page.locator('text=⋮')
    ).first();
    await menuBotao.click();
    await page.waitForTimeout(500);

    await page.getByText('Editar').first().click();
    await page.waitForSelector('text=Editar Transação', { timeout: 8000 });

    await page.screenshot({ path: 'tests/screenshots/t3-modal-editar.png', fullPage: true });

    const inputDesc = page.locator('input[placeholder*="Abastecimento"]').or(
      page.locator('[placeholder*="Abastecimento"]')
    ).first();
    await inputDesc.clear();
    await inputDesc.fill('Teste Playwright - EDITADO');

    const inputValor = page.locator('input[placeholder="0,00"]').or(
      page.locator('[placeholder="0,00"]')
    ).first();
    await inputValor.clear();
    await inputValor.fill('999');

    await page.screenshot({ path: 'tests/screenshots/t3-antes-salvar.png', fullPage: true });

    await page.getByText('Salvar alterações').click();
    await page.waitForSelector('text=Salvar alterações', { state: 'hidden', timeout: 10000 });

    await expect(page.getByText('Teste Playwright - EDITADO').first()).toBeVisible({ timeout: 8000 });
    await page.screenshot({ path: 'tests/screenshots/t3-editada.png', fullPage: true });
    console.log('✅ T3 — Transação editada com sucesso');
  });

  // ── T4 ────────────────────────────────────────────────────────────────────
  test('T4 — Excluir transação', async ({ page }) => {
    await abrirFinancas(page);
    await page.waitForSelector('text=Teste Playwright', { timeout: 10000 });

    const count = await page.getByText('Teste Playwright').count();
    console.log(`  → ${count} transações de teste encontradas`);

    const menuBotao = page.locator('[aria-label="Opções"], [aria-label="Ações"]').or(
      page.locator('text=⋮')
    ).first();
    await menuBotao.click();
    await page.waitForTimeout(500);

    const btnExcluir = page.getByText('Excluir').or(page.getByText('Remover')).first();
    await btnExcluir.click();

    // Confirmação no dialog, se houver
    const btnConfirmar = page.getByText('Confirmar').or(page.getByText('Sim')).or(page.getByText('Deletar'));
    if (await btnConfirmar.isVisible({ timeout: 3000 }).catch(() => false)) {
      await btnConfirmar.first().click();
    }

    await page.waitForTimeout(2000);
    await page.screenshot({ path: 'tests/screenshots/t4-apos-excluir.png', fullPage: true });
    console.log('✅ T4 — Transação excluída com sucesso');
  });

  // ── T5 ────────────────────────────────────────────────────────────────────
  test('T5 — Validação de campos obrigatórios (form vazio)', async ({ page }) => {
    await abrirFinancas(page);
    await abrirNovaTransacao(page);

    await expect(page.getByText('+ Nova Transação').first()).toBeVisible();

    await selecionarTipo(page, 'Saída');

    // Clica em Finalizar SEM preencher valor/descrição/forma
    await page.getByText('Finalizar').click();
    await page.waitForTimeout(600);

    // Modal ainda deve estar aberto
    await expect(page.getByText('Finalizar').first()).toBeVisible();

    await page.screenshot({ path: 'tests/screenshots/t5-validacao.png', fullPage: true });
    console.log('✅ T5 — Modal permaneceu aberto com erros de validação');
  });
});
